# react-admin-boilerplate
React dashboard boilerplate. Has users management, authentication, configurable roles and permissions system. Redux store branches can be created with a few lines of code. Uses react-bootstrap, Redux, Redux-Saga, Volt dashboard designs. API emulation included using MirageJs. Has Cypress onboard for E2E testsing.
